This file package includes a data file and companion file with important metadata information.
Table Notes for this table can be found on data.census.gov at: 
https://data.census.gov/table/ECNNAPCSPRD2022.EC2200NAPCSPRDIND
Once in the table select the table notes button on menu bar above the table.
