This file package includes a data file and companion file with important metadata information.
