# Minimal standard Git source restoration

Base: a full GitHub clone containing PR98 tree `1704e4add770af0cfee0f6179a3dea9453a77f8c`. The 139KB standard pack contains 88 objects absent from that exact published tree, including the exact frozen input, historical graph source, and pilot activation commits and missing tree/blob objects. No raw provider outputs or private workflows are included. This is source restoration, not a complete research archive.

Verify SHA256 in the manifest, then import using built-in Git object validation:

```sh
git -C /path/to/github-clone cat-file -e 1704e4add770af0cfee0f6179a3dea9453a77f8c^{tree}
git -C /path/to/github-clone index-pack --stdin < turbo-service-source-minimal.pack
git -C /path/to/github-clone cat-file -e f5fcbbd82c0fd5b847b26be96ac2a65522ef308a^{commit}
git -C /path/to/github-clone cat-file -e de04aca6da6735eceae5e8ddec2cbec31c0a732a^{commit}
```

In a dedicated clean frozen-input checkout at the ORIGINAL recorded path `/private/tmp/turbo-service-qualified-v2`, import the pack and check out f5fcbbd82c0fd5b847b26be96ac2a65522ef308a detached. Expected tree: c3e3db157f4b9e0c04b38527c4d2f24005fb5ce8. Do not overwrite a differing existing checkout. Import the same pack into publication/replay clones to resolve the original base graph execution commit de04aca6da6735eceae5e8ddec2cbec31c0a732a.

Full ancestor history is deliberately not packaged. In particular de04 parent26d87003ca2d30d238ad604b3c1279c5211c95f3 and the local f5fc parent chain may be absent. Exact object/tree restoration and current validators do not traverse those parents; full-history Git operations may report missing ancestry. No synthetic parents or replacement commits are used.

Verification used a NEW git-init directory `/tmp/turbo-service-published-tree-check`, imported ONLY the published1704e4 tree closure (no commits or history), then this88-object pack. Subtraction used only that published tree closure, never local history. The first narrower pack exposed missing pilot activation commit243fbc; the final pack therefore includes that exact commit and its missing tree closure too. No hidden local ancestry or unreachable objects were copied. Checked out f5fc at exact treec3e3; unchanged graph validation PASSED with five canonical markets. Original historical workflow/input/preparation paths remain necessary:

- /private/tmp/turbo-published-small-qualification/workflow
- /private/tmp/turbo-parity-input (tree4f2262909ab60f99e4a4eb5e06bcaf77806e48fa; existing published historical input capsule)
- /private/tmp/turbo-small-qualification-compact/preparations/family-preparation:912826dc158672ffe1422048
- /private/tmp/turbo-small-qualification-compact/preparations/family-preparation:8e9567722ad643e5177e97b8

Archive those original paths and the final Ember workflow/preparations separately. Cumulative graph/closure validation must omit global input_root/preparation_dirs overrides, allowing each workflow to use its own recorded inputs. Existing paths were used for this validation; archive-only reconstruction remains pending.

Publish the NEW activation/config source commit to GitHub first, check out that exact remote SHA, then use guarded graph_publication.run_graph_release. A same-tree SHA cannot replace a receipt execution identity. Keep the larger69MB bundle locally as full frozen-source history fallback.

Tree-only baseline + final minimal pack: PASS valid=true, five canonical markets; exact frozen HEAD/tree confirmed.
